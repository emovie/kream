package com.itbank.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.itbank.model.KreamDTO;
import com.itbank.service.KreamService;

@Controller
public class HomeController {
	
	@Autowired private KreamService ks;
	
	@GetMapping("/")
	public String home() {
		return "home";
	}	
	
	@GetMapping("/list")
	public void list(Model model) {
		List<KreamDTO> list = ks.selectList();
		model.addAttribute("list", list);
	}
}
