package com.itbank.model;

import java.util.List;

import org.apache.ibatis.annotations.Select;

public interface KreamDAO {

	
	@Select("select * from product order by idx")
	List<KreamDTO> selectList();


}
