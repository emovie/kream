drop sequence product_seq;
drop table product;



create sequence product_seq
    start with 1
    maxvalue 999999999
    increment by 1
    nocache;
    
create table product (
    idx             number          default product_seq.nextval primary key,          
    productname     varchar2(200),
    krname          varchar2(200),
    model           varchar2(2000),
    brand           varchar2(200),
    color           varchar2(200),
    rdate           varchar2(200)   default to_char(sysdate, 'yyyy-MM-dd hh24mi'),
    price           number,
    category        varchar2(200)    
);

-- insert 할때 모든 컬럼을 지정하지 않을거라면, 값을 넣을 컬럼을 values 앞에 명시해야 한다 !!
insert into product 
            (productname, krname, model, brand, color, price, category)
            values
            ('Nike Dunk Low Retro Black', '나이키 덩크 로우 레트로 블랙', 'httpskream-phinf.pstatic.netMjAyMDEyMjhfMjcwMDAxNjA5MTQxMzQ1ODE2.KoWVbwxPPVr_E2VIdtspSX_D0OYseewwgF2MrmCgHxEg.rlgpzHBNbIvwYhcrfRhvTAjyk2nLKyrsPeQOdn-3Ktog.PNGp_c195a4c1e9fe4f379467e4cc0008efe8.pngtype=m', 'Nike', 'WHITEBLACK', 119000, '스니커즈');

insert into product 
            (productname, krname, model, brand, color, price, category)
            values
            ('Jordan 1 Retro High OG Black Mocha', '조던 1 레트로 하이 OG 블랙 모카', 'httpskream-phinf.pstatic.netMjAyMDEwMjJfOCAgMDAxNjAzMzQwOTUzNzMx.nCU7Bumo43r7JZcTRjq4blFOcj33dPIxNYW-_94RtWgg.rJwsoEL3W-f7pgpwfYISb-0HBItIWL04h7p8Ixyp8CUg.PNGp_4cedd884b4a3427ca616bc31b3bf2867.pngtype=m', 'Jordan', 'SAILDARK MOCHA-BLACK-BLACK', 199000, '스니커즈');

insert into product 
            (productname, krname, model, brand, color, price, category)
            values
            ('New Balance 992 Made in USA Grey (D Standard)', '뉴발란스 992 메이드 인 USA 그레이 (D 스탠다드)', 'httpskream-phinf.pstatic.netMjAyMTA2MTBfNTEgMDAxNjIzMjkzNjQyNzc5.g9aG-vgc8cQnKQjeSlYJL1LlxUysCMep3AlQyiqc7SIg.1khk259nJf4u2miraN3PWX6aNbQpo7SIM9itNZ_euLgg.PNGp_6c10d5b4be024655a54cf551743dbdeb.pngtype=m', 'New Balance', 'GREY', 259000, '스니커즈');
            
insert into product 
            (productname, krname, model, brand, color, price, category)
      values
            ('(W) Jordan 1 Low White Wolf Grey', '(W) 조던 1 로우 화이트 울프 그레이', 'httpskream-phinf.pstatic.netMjAyMTA2MTFfMTYzMDAxNjIzMzc3MDU5NjE2.YXUYv4dP5JbQ_9hQ77z8IU_zOsrNZK4dVzontxKJKyUg.2GnOZkZSaefqL0GHUN0iDZxtoeo3xZCXgqCSEkEiPZIg.PNGp_3070b565177c40958942f4cd02129fbf.pngtype=m', 'Jordan', 'WHITEWOLF GREYALUMINUM', 119000, '스니커즈');

insert into product 
            (productname, krname, model, brand, color, price, category)
      values
            ('Nike x Sacai VaporWaffle Sesame and Blue Void', '나이키 x 사카이 베이퍼와플 세서미 앤 블루 보이드', 'httpskream-phinf.pstatic.netMjAyMTA0MjBfMTcyMDAxNjE4ODk2MTkwOTI3.75OG72tkIw8262nz1mkpGzAKOpVl1TWTHrcrXy_ABgQg.UatmoMBKaO65DDEdkQvBOUFcm9SNdTAIfdLrENMIqm0g.PNGp_f5013930e2e14ac9819dbdf8481de5d9.pngtype=m', 'Nike', 'SESAMEBLUE VOID-WHITE', 219000, '스니커즈');



desc product;
select  from product order by idx;

rollback;
commit;






